# Movie Scores with forEach

## Instructions

* Open the [MovieScore](Unsolved/index_starter.js) activity solution from the previous class.

* Refactor the code to use the `forEach` method instead of a `for loop`.

* **Hint:** Remember that `forEach` will pass a function to each element in an array.

- - -

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.