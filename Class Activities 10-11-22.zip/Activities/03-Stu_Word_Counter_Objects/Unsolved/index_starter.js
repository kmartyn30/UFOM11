// Initialize the function

  // Convert string to an array of words
  

  // An object to hold word frequency


  // Iterate through the array and count the occurrence of each word


//  Call the function with the string as a parameter.